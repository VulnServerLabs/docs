---
layout: default
title: Browser Tools
---

# Browser Tools

Recommended browser extensions and techniques for client-side vulnerability testing.
