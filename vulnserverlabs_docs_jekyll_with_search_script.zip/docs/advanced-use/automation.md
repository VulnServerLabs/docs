---
layout: default
title: Automation
---

# Automation

Use Burp Suite, sqlmap, and curl to automate your testing workflows and accelerate findings.
