---
layout: default
title: FAQ
---

# Frequently Asked Questions

### How long are labs available?
Each lab session lasts 8 hours from the time of provisioning.

### Can I use my own tools?
Yes — you can use any local or browser-based tools to test and analyze labs.

### Are labs graded?
Labs are self-paced. Writeups and flags are optionally reviewed if submitted.
