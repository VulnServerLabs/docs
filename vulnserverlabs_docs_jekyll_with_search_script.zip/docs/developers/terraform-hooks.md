---
layout: default
title: Terraform Hooks
---

# Terraform Hooks

Explore how the platform provisions lab infrastructure with Terraform, including session-based triggers.
