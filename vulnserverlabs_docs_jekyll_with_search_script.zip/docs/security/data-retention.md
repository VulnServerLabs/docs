---
layout: default
title: Data Retention
---

# Data Retention

All lab data is temporary. Learn about how long sessions, flags, and writeups are stored.
