---
layout: default
title: Logging
---

# Logging

User actions and lab activity may be logged to support educational feedback and platform integrity.
