---
layout: default
title: Sandbox Environments
---

# Sandbox Environments

Labs run in isolated sandboxes with limited lifetimes to ensure safe experimentation.
