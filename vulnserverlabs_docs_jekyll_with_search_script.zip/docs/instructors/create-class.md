---
layout: default
title: Create a Class
---

# Creating a Class

Learn how to enroll students, distribute lab access, and assign work using VulnServer Labs.
