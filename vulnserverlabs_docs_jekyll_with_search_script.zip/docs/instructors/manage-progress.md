---
layout: default
title: Manage Progress
---

# Managing Progress

Track student or team member progress through dashboard features and submission records.
