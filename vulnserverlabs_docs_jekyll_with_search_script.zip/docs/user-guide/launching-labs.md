---
layout: default
title: Launching Labs
---

# Launching Labs

From your dashboard, click “Launch” to start a new session. Labs spin up in seconds.
