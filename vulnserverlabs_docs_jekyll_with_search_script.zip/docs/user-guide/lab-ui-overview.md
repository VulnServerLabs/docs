---
layout: default
title: Lab UI Overview
---

# Lab UI Overview

Each lab features a terminal, HTTP viewer, and instructions panel.
