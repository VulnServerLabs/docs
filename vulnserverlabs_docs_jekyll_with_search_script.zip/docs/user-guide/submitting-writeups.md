---
layout: default
title: Submitting Writeups
---

# Submitting Writeups

Submit your results via the submission panel — flags, screenshots, and write-ups are all accepted.
