---
layout: default
title: Web Vulnerabilities
---

# Web Vulnerabilities

Covers XSS, SQL Injection, CSRF, and other web-related flaws commonly found in OWASP Top 10.
