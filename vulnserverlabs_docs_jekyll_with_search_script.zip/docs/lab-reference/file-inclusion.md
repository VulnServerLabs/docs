---
layout: default
title: File Inclusion
---

# File Inclusion Attacks

Learn to exploit local and remote file inclusion, file upload flaws, and path traversal.
