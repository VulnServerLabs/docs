---
layout: default
title: Authentication Bypass
---

# Authentication Bypass

Explore vulnerabilities in login mechanisms such as weak tokens, JWT tampering, and session hijacking.
