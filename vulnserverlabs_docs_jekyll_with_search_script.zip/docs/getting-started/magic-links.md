---
layout: default
title: Magic Links
---

# How Magic Links Work

Magic links are time-limited login URLs that provide passwordless access to your dashboard and lab sessions.
