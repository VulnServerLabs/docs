---
layout: default
title: Create Account
---

# Creating Your VulnServer Labs Account

To begin, simply enter your email on our signup form. We'll send you a secure Magic Link that logs you in automatically.
