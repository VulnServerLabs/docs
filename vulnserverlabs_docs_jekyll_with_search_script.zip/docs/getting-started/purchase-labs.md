---
layout: default
title: Purchase Labs
---

# Purchase a Lab Session

Lab sessions are available via Stripe Checkout. You can select a plan and launch your lab within minutes.
