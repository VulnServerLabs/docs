---
layout: default
title: Getting Started
---

# Getting Started

Explore the topics below in the **Getting Started** section.

## 📚 Topics

- [Create Account]({ '{ site.baseurl }' }/getting-started/create-account.html)
- [Purchase Labs]({ '{ site.baseurl }' }/getting-started/purchase-labs.html)
- [Magic Links]({ '{ site.baseurl }' }/getting-started/magic-links.html)
