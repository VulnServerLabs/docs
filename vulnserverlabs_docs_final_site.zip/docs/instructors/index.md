---
layout: default
title: Instructors
---

# Instructors

Explore the topics below in the **Instructors** section.

## 📚 Topics

- [Create Class]({ '{ site.baseurl }' }/instructors/create-class.html)
- [Manage Progress]({ '{ site.baseurl }' }/instructors/manage-progress.html)
- [Lms Integration]({ '{ site.baseurl }' }/instructors/LMS-integration.html)
