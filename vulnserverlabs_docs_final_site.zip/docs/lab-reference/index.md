---
layout: default
title: Lab Reference
---

# Lab Reference

Explore the topics below in the **Lab Reference** section.

## 📚 Topics

- [Web Vulns]({ '{ site.baseurl }' }/lab-reference/web-vulns.html)
- [Auth Bypass]({ '{ site.baseurl }' }/lab-reference/auth-bypass.html)
- [File Inclusion]({ '{ site.baseurl }' }/lab-reference/file-inclusion.html)
- [Rce Chain]({ '{ site.baseurl }' }/lab-reference/rce-chain.html)
